package com.nimble.helper.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class ReportController {

    @RequestMapping("/ui-report")
    public String home() {
        return "/ui-report/index.html";
    }

}
