package com.nimble.helper;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class UiHelperApplication {

	public static void main(String[] args) {
		SpringApplication.run(UiHelperApplication.class, args);
	}
}
