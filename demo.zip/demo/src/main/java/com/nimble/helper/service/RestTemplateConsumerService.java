package com.nimble.helper.service;

import org.springframework.stereotype.Service;

@Service
public class RestTemplateConsumerService {
}
