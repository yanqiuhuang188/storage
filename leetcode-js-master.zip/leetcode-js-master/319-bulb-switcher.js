/**
 * @param {number} n
 * @return {number}
 */
const bulbSwitch = function(n) {
  return Math.floor(Math.sqrt(n));
};
